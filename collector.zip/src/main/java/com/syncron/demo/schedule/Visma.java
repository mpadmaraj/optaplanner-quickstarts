package com.syncron.demo.schedule;

import com.syncron.demo.MetricEmitter;
import com.syncron.demo.protocols.SyncronRest;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Date;


@Service
@Slf4j
public class Visma {

    private final SyncronRest syncronRest;

    private final QueueMessagingTemplate messagingTemplate;

    @Autowired
    MetricEmitter metricEmitter;

    public Visma(SyncronRest syncronRest, QueueMessagingTemplate messagingTemplate) {
        this.syncronRest = syncronRest;
        this.messagingTemplate = messagingTemplate;
    }

    @Scheduled(fixedRate = 120000)
    public void scheduleVisma(){
        log.info("Running schedule at {}", new Date());
        String response = syncronRest.getRestData();
        if(null != response){
            messagingTemplate.convertAndSend("syncron-curator", response);
        }
        //JSONObject jsonObject = new JSONObject(response);
        /*if(jsonObject.has("data")){
            log.info("data is present!");
            messagingTemplate.convertAndSend("syncron-curator", response);
            *//*JSONArray data = jsonObject.getJSONArray("data");
            data.forEach(element->{
                JSONObject obj = (JSONObject) element;
                log.info("shippingDestinationType: {}", obj.getString("shippingDestinationType"));
                messagingTemplate.convertAndSend("syncron-curator", obj.toString());
            });
        }*/
    }
}
