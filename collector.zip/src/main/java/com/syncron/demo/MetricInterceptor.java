package com.syncron.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.concurrent.ThreadLocalRandom;

@Component
public class MetricInterceptor implements HandlerInterceptor {
    static final String REQUEST_START_TIME = "requestStartTime";
    static int mimicQueueSize;
    @Autowired
    MetricEmitter metricEmitter;

    @Override
    public boolean preHandle(
            HttpServletRequest request, HttpServletResponse response, Object handler) {

        request.setAttribute(REQUEST_START_TIME, System.currentTimeMillis());
        return true;
    }

    @Override
    public void postHandle(
            HttpServletRequest request,
            HttpServletResponse response,
            Object handler,
            ModelAndView modelAndView) {
        try {
            String statusCode = String.valueOf(response.getStatus());

            // calculate return time
            Long requestStartTime = (Long) request.getAttribute(REQUEST_START_TIME);
            metricEmitter.emitReturnTimeMetric(
                    System.currentTimeMillis() - requestStartTime, request.getServletPath(), statusCode);

            // emit http request load size
            int loadSize = request.getContentLength() + mimicPayloadSize();
            metricEmitter.emitBytesSentMetric(loadSize, request.getServletPath(), statusCode);
            metricEmitter.updateTotalBytesSentMetric(loadSize, request.getServletPath(), statusCode);
            // mimic a queue size reporter
            int queueSizeChange = mimicQueueSizeChange();
            metricEmitter.emitQueueSizeChangeMetric(
                    queueSizeChange, request.getServletPath(), statusCode);
            metricEmitter.updateActualQueueSizeMetric(
                    queueSizeChange, request.getServletPath(), statusCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static int mimicPayloadSize() {
        return ThreadLocalRandom.current().nextInt(1000);
    }

    private static int mimicQueueSizeChange() {
        int newQueueSize = ThreadLocalRandom.current().nextInt(100);
        int queueSizeChange = newQueueSize - mimicQueueSize;
        mimicQueueSize = newQueueSize;
        return queueSizeChange;
    }
}