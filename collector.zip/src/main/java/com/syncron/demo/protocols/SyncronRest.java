package com.syncron.demo.protocols;

import com.syncron.demo.MetricEmitter;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.semconv.trace.attributes.SemanticAttributes;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.Random;


@Service
@Slf4j
public class SyncronRest {

    private final RestTemplate restTemplate;
    @Autowired
    MetricEmitter metricEmitter;

    public SyncronRest(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }


    public String getRestData(){
        log.info("Calling  rest GET at {}", new Date());
        ResponseEntity<String> response;
        Span span = Span.current();
        span.setAttribute("CustomerId",1);
        try {
            Long startTime = System.currentTimeMillis();
            String url = "http://syncron.mocklab.io/api/v1/purchaseorder";
            Random rand = new Random();
            int n = rand.nextInt(100);
            if(n % 2 == 0){
                url="http://syncron.mocklab.io/api/v2/purchaseorder";
            }
            response = restTemplate.getForEntity(url, String.class);
/*        metricEmitter.emitReturnTimeMetric(
                System.currentTimeMillis() - startTime,"Purchase Order", "200");*/
            // metricEmitter.emitBytesSentMetric(response.getHeaders().getContentLength(), "Purchase Order", "200");
            log.info("Got response at {}", new Date());
            return response.getBody();
        }  catch (Throwable e) {
            span.recordException(e, Attributes.of(SemanticAttributes.EXCEPTION_ESCAPED, true));
            span.setStatus(StatusCode.ERROR);
            span.setAttribute("exception.message",e.getMessage());
            throw e;
        } finally {
            span.end();
        }

    }
}
