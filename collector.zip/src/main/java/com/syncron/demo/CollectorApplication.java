package com.syncron.demo;

import com.amazonaws.services.sqs.AmazonSQSAsync;
import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.aws.autoconfigure.context.ContextInstanceDataAutoConfiguration;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.OkHttp3ClientHttpRequestFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.TimeUnit;

@SpringBootApplication
@EnableAutoConfiguration(exclude = {ContextInstanceDataAutoConfiguration.class})
@EnableScheduling
public class CollectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollectorApplication.class, args);
	}

	@Bean
	public MetricEmitter buildMetricEmitter() {
		return new MetricEmitter();
	}


/*	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();

		// create the okhttp client builder
		OkHttpClient.Builder builder = new OkHttpClient.Builder();
		ConnectionPool okHttpConnectionPool = new ConnectionPool(50, 30, TimeUnit.SECONDS);
		builder.connectionPool(okHttpConnectionPool);
		builder.connectTimeout(20, TimeUnit.SECONDS);
		builder.retryOnConnectionFailure(false);
		// embed the created okhttp client to a spring rest template
		restTemplate.setRequestFactory(new OkHttp3ClientHttpRequestFactory(builder.build()));

		return restTemplate;
	}*/

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}


	@Bean
	public QueueMessagingTemplate queueMessagingTemplate(
			AmazonSQSAsync amazonSQSAsync) {
		return new QueueMessagingTemplate(amazonSQSAsync);
	}

}
