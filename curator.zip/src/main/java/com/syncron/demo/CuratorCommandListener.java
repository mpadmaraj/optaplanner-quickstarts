package com.syncron.demo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@Slf4j
public class CuratorCommandListener {

    @SqsListener(value = "syncron-curator", deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
    public void receive(@Headers Map<String, String> header, @Payload String message) {
        System.out.println("Header = " + header.get("AWSTraceHeader") );
        log.info("Incoming message: " + message);

    }
}
